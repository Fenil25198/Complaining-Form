<?php 

$con = mysqli_connect('localhost', 'root', '','final_project');

if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
else {
	echo" Thank You For Contact Us";
}

$Name = $_POST['Name'];
$email = $_POST['email'];
$Complain = $_POST['Complain'];
$sql = "INSERT INTO usercmp (ID, Name, email, Complain) VALUES('', '$Name', '$email', '$Complain')";

if( mysqli_query($con, $sql)){
 header("location: FinalProject.html");
    exit;

 } 
else {
 	echo"please try again".mysqli_error($con);
 }

mysqli_close($con);



?>